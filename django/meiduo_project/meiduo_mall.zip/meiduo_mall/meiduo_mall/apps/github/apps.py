from django.apps import AppConfig


class GithubConfig(AppConfig):
    name = 'github'
