from django.apps import AppConfig


class MeiduoAdminConfig(AppConfig):
    name = 'meiduo_admin'
