#!/usr/bin/python3
# python version:   Python 3.6
# System version:   Linux
# The date of:      19-4-22 下午12:32
# The author:       小喂喂  
# IDE:              PyCharm


def main():
    pass


if __name__ == '__main__':
    main()