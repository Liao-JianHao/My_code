from django.apps import AppConfig


class GoodsConfig(AppConfig):
    name = 'goods'
