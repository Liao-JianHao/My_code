from django.apps import AppConfig


class SinaConfig(AppConfig):
    name = 'sina'
