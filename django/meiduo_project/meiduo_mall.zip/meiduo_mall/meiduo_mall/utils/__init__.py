#!/usr/bin/python3
# python version:   Python 3.6
# System version:   Linux
# The date of:      19-4-22 上午10:21
# The author:       小喂喂  
# IDE:              PyCharm


def main():
    pass


if __name__ == '__main__':
    main()